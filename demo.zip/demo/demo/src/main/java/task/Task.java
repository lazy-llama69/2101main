package task;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import java.util.ArrayList;
import java.util.List;

public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private int complexity;

    private Tag tag;

    private List<Priority> priority;

    private List<String> assignees;

    private String descriptions;

    private Status status;

    private Stage stage;

    private

    enum Tag {
        FRONTEND, BACKEND, API, DATABASE, FRAMEWORK, TESTING, UI, UX
    }

    enum Priority{
        LOW, MEDIUM, IMPORTANT, URGENT
    }

    enum Status{
        NOT_STARTED, IN_PROGRESS, COMPLETED
    }

    enum Stage{
        PLANNING, DEVELOPMENT, TESTING
    }



    public Task() {
        this.id = null;
        this.name = "new Task";
        this.complexity = 0;
        this.tag = Tag.FRONTEND;
        this.priority = new ArrayList<>();
        this.assignees = new ArrayList<>();
        this.descriptions = "New Task";
        this.status = Status.NOT_STARTED;
        this.stage = Stage.PLANNING;
    }

    // Getter for id
    public Long getId() {
        return id;
    }

    // Setter for id
    public void setId(Long id) {
        this.id = id;
    }

    // Getter for title
    public String getName() {
        return name;
    }

    // Setter for title
    public void setName(String newName) {
        this.name = newName;
    }

    // Getter for description
    public String getDescriptions() {
        return descriptions;
    }

    // Setter for description
    public void setDescription(String newDescription) {
        this.descriptions = newDescription;
    }

    public int getComplexity() {
        return complexity;
    }

    // Setter for description
    public void setComplexity(int newComplexity) {
        this.complexity = newComplexity;
    }

    public List<String> getAssignees() {
        return assignees;
    }

    // Setter for description
    public void addAssignees(String newAssignees) {
        this.assignees.add(newAssignees);
    }

    public Status getStatus() {
        return status;
    }

    // Setter for description
    public void setStatus(String newStatus) {
        try {
            Status enumStatus = Status.valueOf(newStatus);
            this.status = enumStatus;
        } catch (IllegalArgumentException e) {

        }
    }

    public Stage getStage() {
        return stage;
    }

    // Setter for description
    public void setStage(String newStage) {
        try {
            Stage enumStage = Stage.valueOf(newStage);
            this.stage = enumStage;
        } catch (IllegalArgumentException e) {

        }
    }

    public List<Priority> getPriority() {
        return priority;
    }

    // Setter for description
    public void addPriority(String newPriority) {
        try {
            Priority enumPriority = Priority.valueOf(newPriority);
            this.priority.add(enumPriority);
        } catch (IllegalArgumentException e) {

        }
    }

    public Tag getTag() {
        return tag;
    }

    // Setter for description
    public void setTag(String newTag) {
        try {
            Tag enumTag = Tag.valueOf(newTag);
            this.tag = enumTag;
        } catch (IllegalArgumentException e) {

        }
    }

}
